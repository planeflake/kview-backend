from sqlalchemy import Table,Date, Column, Integer, String, Float, DateTime, MetaData, ForeignKey
from datetime import datetime

metadata = MetaData()

aoi = Table(
    "aois",
    metadata,
    Column("id", Integer, primary_key=True),
    Column("name", String),
    Column("geom", String))

ndvi = Table(
    "ndvi",
    metadata,
    Column("id", Integer, primary_key=True),
    Column("aoi_id", Integer, ForeignKey("aoi.id")),
    Column("filepath", String),
    Column("processed_date", DateTime),
    Column("created_at", DateTime),
)

ndvi_statistics = Table(
    "ndvi_statistics",
    metadata,
    Column("id", Integer, primary_key=True),
    Column("aoi_id", Integer, ForeignKey("aoi.id")),
    Column("date", Date),
    Column("min_ndvi", Float),
    Column("max_ndvi", Float),
    Column("median_ndvi", Float),
    Column("created_at", DateTime),
)

algae_statistics = Table(
    "algae_statistics",
    metadata,
    Column("id", Integer, primary_key=True),
    Column("aoi", Integer, ForeignKey("aoi.id")),
    Column("datetime", Date),
    Column("min", Float),
    Column("max", Float),
    Column("mean", Float)
)