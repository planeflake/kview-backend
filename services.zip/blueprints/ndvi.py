from fastapi import APIRouter, HTTPException
from typing import List, Optional
from datetime import datetime, date
from pydantic import BaseModel, field_serializer
from services.ndvi_service import calculate_ndvi
from services.aoi_service import calculate_aoi
from database import database
from models.models import ndvi_statistics, aoi
import logging

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

ndvi_router = APIRouter()

class AOIResponse(BaseModel):
    id: int
    name: str
    geom: str

class NDVIStatsCreate(BaseModel):
    aoi_id: int
    date: str
    min_ndvi: float
    max_ndvi: float
    median_ndvi: float

class NDVIResponse(BaseModel):
    id: int
    aoi_id: int
    date: date
    min_ndvi: float
    max_ndvi: float
    median_ndvi: float
    created_at: datetime

    @field_serializer('date')
    def serialize_date(self, date_value: datetime) -> str:
        return date_value.isoformat()

    class Config:
        from_attributes = True

@ndvi_router.get("/", response_model=List[NDVIResponse])
async def get_ndvi():
    try:
        query = ndvi_statistics.select()
        results = await database.fetch_all(query)
        logger.debug(f"Raw results: {results}")
        print("Test")
        # Convert records to model instances
        response_data = []
        for r in results:
            data = dict(r)
            logger.debug(f"Processing record: {data}")
            response_data.append(NDVIResponse(**data))
        
        logger.debug(f"Processed response data: {response_data}")
        return response_data
    except Exception as e:
        logger.error(f"Error in get_ndvi: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))
    
@ndvi_router.post("/")
async def create_ndvi(filepath: str):
    result = calculate_ndvi(filepath)
    return {"message": "NDVI created successfully", "data": result}

# AOI endpoints
@ndvi_router.get("/aoi")
async def get_aoi(aoi_id: int):
    print("This will appear immediately", flush=True)
    query = aoi.select().where(aoi.c.id == aoi_id)
    result = await database.fetch_one(query)
    if not result:
        raise HTTPException(status_code=404, detail="AOI not found")
    return AOIResponse(
        id=result['id'],
        name=result['name'],
        geom=result['geom']
    )

@ndvi_router.post("/aoi")
async def create_aoi(name: str, geometry: str):
    query = aoi.insert().values(
        name=name,
        geom=geometry,
        created_at=datetime.now()
    )
    last_record_id = await database.execute(query)
    return {"message": "AOI created successfully", "id": last_record_id}

# Stats endpoints
@ndvi_router.get("/stats")
async def get_ndvi_stats(
    aoi_id: Optional[int] = None,
    date: Optional[str] = None
):
    print("This will appear immediately", flush=True)
    query = ndvi_statistics.select()
    if aoi_id:
        query = query.where(ndvi_statistics.c.aoi_id == aoi_id)
    if date:
        query = query.where(ndvi_statistics.c.date == date)
    results = await database.fetch_all(query)
    return {"ndvi_stats": results}

@ndvi_router.post("/stats")
async def create_ndvi_stats(stats: NDVIStatsCreate):
    print("Test")
    query = ndvi_statistics.insert().values(
        **stats.dict(),
        created_at=datetime.now()
    )
    last_record_id = await database.execute(query)
    return {"message": "Stats created successfully", "id": last_record_id}